#ifndef _CATEGORY_H
#define _CATEGORY_H

// Name: Kaushal Banthia
// Roll Number: 19CS10039

namespace Category
{
    struct GeneralType{};
    struct LadiesType{};
    struct DivyaangType{};
    struct SeniorCitizenType{};
    struct TatkalType{};
    struct PremiumTatkalType{};
}

#endif