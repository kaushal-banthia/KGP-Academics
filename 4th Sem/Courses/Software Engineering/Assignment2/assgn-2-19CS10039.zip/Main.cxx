#include "Fraction.hxx"

//************************
//this file has the main function implemented here
//************************

void TestFraction();

int main()
{
    TestFraction();
    return 0;
}