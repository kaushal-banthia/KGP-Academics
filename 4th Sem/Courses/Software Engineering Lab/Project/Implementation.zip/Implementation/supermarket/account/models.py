from django.db import models
from django.contrib.auth.models import User


# class Employee(User):
#     username
#     password
#     email
#     isClerk


# class Clerk(Employee):
#     transaction




