To run the file
1. Use Google Colab and open the link provided in the report.

1. When opening the file in Google Colab, all you need to do to execute the code is run each cell in the file.
This can be done by clicking on the run button, or shift + enter for each cell.
**NOTE**: One important thing that needs to be done is, uploading the attached opt_digits_tes and opt_digits_tra csv files to the Google Colab runtime.
This should be added in the folder named 'content' (the folder that contains 'sample_data') (the one that shows up when clicking the file button on the 
left bar in Google Colab).

NOTE: This file can be run as in Jupyter Notebook too, but for that many libraries would be required and installing them requires a lot of space and time
and thus this method is not preferred, as Google Colab already provides us with all the required libraries pre-installed in its environment!